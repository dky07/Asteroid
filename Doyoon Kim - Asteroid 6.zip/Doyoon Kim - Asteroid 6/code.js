/**
 * Lab Goal: This lab was designed to teach you
 * how to find collisions with many objects
 * 
 * Lab Description: Detect Collision
 */

// Initialize variables

var bg1 ={x:0,y:0,w:320,h:450,s:2,img:"bg1"};
var bg2 ={x:-320,y:0,w:320,h:450,s:2,img:"bg2"};
var rocket = {x:160, y:360, w:30, h:50, s:10, img:"rocket"};
var asteroid1 = {x:randomNumber(30,290), y:-100, w:60, h:60, s:randomNumber(3,5), img:"meteor"};
var asteroid2 = {x:randomNumber(30,290), y:-100, w:60, h:60, s:randomNumber(3,5), img:"meteor2"};
var asteroid3 = {x:randomNumber(30,290), y:-100, w:60, h:60, s:randomNumber(3,5), img:"rock"};
var score = 0;

//setting scene
drawBackground();
drawRocket();
drawAsteroids();
drawScore();
  
//system code
timedLoop(50, function() {
  scrollBackground ();
  moveAsteroid(asteroid1) ;
  moveAsteroid(asteroid2) ;
  moveAsteroid(asteroid3);
  checkEnd();
});

//rocket movement code
onEvent("screen1", "keydown", function(event) {
    if (event.key === "Left") {
        rocket.x -= rocket.s; // Move the rocket left
    }
    if (event.key === "Right") {
        rocket.x += rocket.s; // Move the rocket right
    }
    if (event.key === "Down") {
        rocket.y += rocket.s; // Move the rocket down
    }
    if (event.key === "Up") {
        rocket.y -= rocket.s; // Move the rocket up
    }
setPosition(rocket.img, rocket.x, rocket.y, rocket.w, rocket.h);
});

//draw background
function drawBackground() {
  image(bg1.img, "assets/6062b.png");
  image(bg2.img, "assets/6062a.png");
  setProperty(bg1.img, "fit", "cover");
  setProperty(bg2.img, "fit", "cover");
}

//drawing score, rocket, and asteroids
function drawScore(){
  textLabel("score", "Score: ");
  setPosition("score",200,20,110,30);
  setProperty("score", "text-color","green");
  setProperty("score", "border-color","green");
  setProperty("score", "border-width",5);
  setProperty("score", "border-radius",5);
}
function drawRocket() {
  image(rocket.img, "assets/rocket.gif");
  setProperty(rocket.img, "fit","fill");
  setPosition(rocket.img, rocket.x, rocket.y, rocket.w, rocket.h);
}
function drawAsteroids() {
  //draw asteroid1
  image(asteroid1.img, "assets/meteor.png");
  setProperty(asteroid1.img, "fit","fill");
  setPosition(asteroid1.img, asteroid1.x, asteroid1.y, asteroid1.w, asteroid1.h);
  //draw asteroid2
  image(asteroid2.img, "assets/meteor2.png");
  setProperty(asteroid2.img, "fit","fill");
  setPosition(asteroid2.img, asteroid2.x, asteroid2.y, asteroid2.w, asteroid2.h);
  //draw asteroid3
  image(asteroid3.img, "assets/rock.png");
  setProperty(asteroid3.img, "fit","fill");
  setPosition(asteroid3.img, asteroid3.x, asteroid3.y, asteroid3.w, asteroid3.h);
}


//asteroids go down the screen
function moveAsteroid(asteroid) {
  asteroid.y += asteroid.s;
  checkOverlap(asteroid);
  setPosition(asteroid.img, asteroid.x, asteroid.y, asteroid.w, asteroid.h);
  checkCollision(asteroid);
  
}

//collision check (update score as necessary)
function checkCollision(asteroid) {
    var xOv = Math.max(0, Math.min(rocket.x + rocket.w, asteroid.x + asteroid.w) - Math.max(rocket.x, asteroid.x) + 1);
    var yOv = Math.max(0, Math.min(rocket.y + rocket.h, asteroid.y + asteroid.h) - Math.max(rocket.y, asteroid.y) + 1);

    if (xOv > 0 && yOv > 0) {
        // Collision detected
        score++;
        score++;
        setText("score", "Score: " + score);
        removeAsteroid(asteroid);
    }
    else if(asteroid.y>450) {
      score--;
      setText("score", "Score: " + score);
    }
}


//resetting asteroids
function removeAsteroid(asteroid) {
    asteroid.y = -100;
    asteroid.x = randomNumber(10, 300);
    asteroid.s = randomNumber(3, 7);
    setPosition(asteroid.img, asteroid.x, asteroid.y, asteroid.w, asteroid.h);
}


//resets asteroids when off screen and updates score
function checkOverlap (asteroid) {
  if (asteroid.y >= 450) {
    removeAsteroid(asteroid);
    if (score>0){
      score -= 1;
      setText("score", "Score: " + score);
    if (score===0){
      score = 0;
      setText("score", "Score: " + score);
    }
    }
  }  
}

//scrolls background
function scrollBackground(){
  bg1.x += bg1.s;
  bg2.x += bg2.s;
  setPosition(bg1.img, bg1.x,bg1.y,bg1.w,bg1.h);
  setPosition(bg2.img, bg2.x,bg2.y,bg2.w,bg2.h);
  if (bg1.x >= 319) {
    bg1.x = -320;
  }
  if (bg2.x >= 320) {
    bg2.x = -320;
  }
}

//check if game over
function checkEnd(){
  if(score>=10){
    stopTimedLoop();
    setScreen("screen2");
  }
}


